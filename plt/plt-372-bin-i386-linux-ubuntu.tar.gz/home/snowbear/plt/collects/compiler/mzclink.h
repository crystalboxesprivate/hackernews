
#define LOCAL_PROC(x) x
