package colors;

public class Green implements IColor { }
