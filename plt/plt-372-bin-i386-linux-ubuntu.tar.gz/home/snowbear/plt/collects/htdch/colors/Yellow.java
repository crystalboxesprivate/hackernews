package colors;

public class Yellow implements IColor { }
