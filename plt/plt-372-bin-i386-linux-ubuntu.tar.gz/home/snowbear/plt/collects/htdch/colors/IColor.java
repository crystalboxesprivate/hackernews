package colors;

public interface IColor { }
