package colors;

public class Blue implements IColor { }
