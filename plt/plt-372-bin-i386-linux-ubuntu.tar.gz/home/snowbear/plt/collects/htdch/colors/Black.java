package colors;

public class Black implements IColor { }
