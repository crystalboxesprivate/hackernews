package colors;

public class White implements IColor { }
