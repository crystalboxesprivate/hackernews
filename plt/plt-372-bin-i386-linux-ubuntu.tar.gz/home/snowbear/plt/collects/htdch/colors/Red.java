package colors;

public class Red implements IColor { }
