package graphics;

public class Yellow extends Color { 
  public String toString() { return "yellow"; }
  public boolean equals(Object o) { return o instanceof Yellow; }
}
