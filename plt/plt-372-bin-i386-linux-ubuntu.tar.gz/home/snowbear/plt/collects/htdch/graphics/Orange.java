package graphics;

public class Orange extends Color {
  public String toString() { return "orange"; }
  public boolean equals(Object o) { return o instanceof Orange; }
}