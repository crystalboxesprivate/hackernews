package graphics;

public class Red extends Color { 
   public String toString() { return "red"; }
   public boolean equals(Object o) { return o instanceof Red; }
}