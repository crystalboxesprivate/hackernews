package graphics;

public class Green extends Color { 
  public String toString() { return "green"; }
  public boolean equals(Object o) { return o instanceof Green;}
}
