package graphics;

public abstract class Color { 
}