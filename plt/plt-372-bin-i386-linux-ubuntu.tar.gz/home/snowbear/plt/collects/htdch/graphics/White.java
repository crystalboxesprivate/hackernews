package graphics;

public class White extends Color { 
   public String toString() { return "white"; }
   public boolean equals(Object o) { return o instanceof White; }
}
