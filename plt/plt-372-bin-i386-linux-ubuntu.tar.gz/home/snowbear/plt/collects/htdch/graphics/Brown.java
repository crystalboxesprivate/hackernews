package graphics;

public class Brown extends Color {
  public String toString() { return "brown"; }
  public boolean equals(Object o) { return o instanceof Brown; }
}