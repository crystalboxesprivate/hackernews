package graphics;

public class Purple extends Color {
  public String toString() { return "purple";}
  public boolean equals(Object o) { return o instanceof Purple; }
}