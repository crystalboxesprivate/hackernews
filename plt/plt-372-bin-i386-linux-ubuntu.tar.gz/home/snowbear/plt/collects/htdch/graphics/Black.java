package graphics;

public class Black extends Color {

   public String toString() { return "black"; }
  
   public boolean equals(Object o) { return o instanceof Black; }

  // public dynamic toScheme() { return rename.makeObj( mred.colorObj, 0, 0, 0); }

}