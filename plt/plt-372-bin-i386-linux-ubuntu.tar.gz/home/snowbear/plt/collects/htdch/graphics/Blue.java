package graphics;

public class Blue extends Color {

   public String toString() { return "blue"; }
  
   public boolean equals(Object o) { return o instanceof Blue; }

  // public dynamic toScheme() { return rename.makeObj( mred.colorObj, 0, 0, 0); }

}