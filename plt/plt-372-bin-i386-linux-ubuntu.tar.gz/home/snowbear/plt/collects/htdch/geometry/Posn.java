package geometry;

public class Posn {
  public int x, y;

  public Posn( int x, int y ) {
    this.x = x;
    this.y = y;
  }
}
