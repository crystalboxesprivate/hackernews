#define PLD_null

