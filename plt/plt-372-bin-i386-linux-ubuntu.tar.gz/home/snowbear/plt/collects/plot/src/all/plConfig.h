#ifndef __PLCONFIG_H__
#define __PLCONFIG_H__
#define LIB_DIR "..\\..\\..\\lib"
#define BIN_DIR "..\\..\\..\\bin"
#define DATA_DIR "..\\..\\..\\lib"
#define DRV_DIR "..\\..\\..\\lib"
#define VERSION "5.2.1"
#define PL_DOUBLE
#endif
